Registration and Login with Spring Boot, Spring Security, Thymeleaf, Hibernate and MySQL


